# CRUD-PHP
Bagaimana Membuat sistem CRUD (Create,Read,Update,Delete) dengan Bahasa Pemrograman PHP

Berikut Langkah-langkahnya:

    1- Buat tabel di Database
  
    2- Koneksikan Aplikasi kita ke Database
  
    3- Mulai buat Aplikasi yang ingin kita buat sesuai dengan kebutuhan kita 



NB:

Jangan lupa Nama Database dan tabel disesuaikan dengan yang Database Yang anda buat 

Semoga Bermanfaat :)
